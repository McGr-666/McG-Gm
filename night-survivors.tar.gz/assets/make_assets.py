"""Make the game pictures from raw_art/ with Pillow. Run me on your computer:

    python3 -m make_assets

raw_art/ is never changed. Everything I make goes into assets/ as finished
PNG files, so main.py only has to load them (that also works in a browser).
"""

import json
from pathlib import Path

from PIL import Image

ROOT = Path(__file__).resolve().parent
RAW = ROOT / "raw_art"
OUT = ROOT / "assets"

# The two crystals, coloured from raw_art/gem.png: dark inside, bright edge.
GEMS = {
    "gem_blue": {"dark": (26, 62, 168), "bright": (178, 228, 255)},
    "gem_pink": {"dark": (166, 24, 116), "bright": (255, 188, 238)},
}


def scale_factor():
    """How much bigger than the original, from data/game.json."""
    data = json.loads((ROOT / "data" / "game.json").read_text())
    return int(data["art"]["scale"])


def enlarge(source, factor):
    """Nearest neighbour: big clean squares, no blurring."""
    size = (source.width * factor, source.height * factor)
    return source.resize(size, Image.NEAREST)


def tint(source, dark, bright):
    """Keep the shape and alpha, but paint it from dark to bright by old brightness."""
    src = source.convert("RGBA")
    out = Image.new("RGBA", src.size)
    old = src.load()
    new = out.load()
    for y in range(src.height):
        for x in range(src.width):
            r, g, b, a = old[x, y]
            if a == 0:
                continue
            light = (0.3 * r + 0.6 * g + 0.1 * b) / 255.0
            color = tuple(round(d + (hi - d) * light) for d, hi in zip(dark, bright))
            new[x, y] = (*color, a)
    return out


def save(image, name):
    image.save(OUT / f"{name}.png")
    print(f"assets/{name}.png  {image.width}x{image.height}")


def main():
    OUT.mkdir(exist_ok=True)
    factor = scale_factor()
    for path in sorted(RAW.glob("*.png")):
        art = Image.open(path).convert("RGBA")
        save(enlarge(art, factor), path.stem)
    gem = Image.open(RAW / "gem.png").convert("RGBA")
    for name, colors in GEMS.items():
        save(enlarge(tint(gem, colors["dark"], colors["bright"]), factor), name)


if __name__ == "__main__":
    main()
