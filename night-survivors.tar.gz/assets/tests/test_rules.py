"""Tests for rules.py only (no drawing, no pictures, no sound).

Every number comes from data/game.json, so changing the design means changing
the data file, never the test code.
"""

import math
import unittest

import rules


def ticks(data, seconds):
    return round(seconds / data["time_step"])


class RuleTests(unittest.TestCase):
    def setUp(self):
        self.data = rules.load_data()
        self.dt = self.data["time_step"]

    def patched(self, **changes):
        """A copy of the design numbers with a few values changed for one test."""
        return dict(self.data, **changes)

    def solo_game(self, weapons=False, seed=1):
        """Nothing spawns by itself, so each test can place its own enemies."""
        data = self.patched(waves=[])
        if not weapons:
            data["start_weapons"] = []
        return rules.Game(data, seed=seed)

    def wave_game(self, seed=1):
        """The real spawn rules, but no shooting, so enemies only pile up."""
        return rules.Game(self.patched(start_weapons=[]), seed=1)

    def give(self, game, name, level=1):
        game.weapons.append({"name": name, "level": level, "cool": 0.0, "hits": {}})

    def unkillable(self, game, x, y):
        """An enemy that cannot die and does not move, for weapon tests."""
        game.data["enemies"] = dict(game.data["enemies"])
        game.data["enemies"]["dummy"] = dict(
            self.data["enemies"]["bat"], hp=10 ** 6, speed=0
        )
        return game.add_enemy("dummy", x, y)

    def tough_game(self, seed=1):
        """The real waves, no shooting, and a hero who cannot die: a pure spawn test."""
        return rules.Game(
            self.patched(
                hero=dict(self.data["hero"], max_hp=10 ** 6), start_weapons=[]
            ),
            seed=seed,
        )

    def run_for(self, game, seconds):
        for _ in range(ticks(self.data, seconds)):
            game.step()
        return game

    def bosses(self, game):
        return [e for e in game.enemies if self.data["enemies"][e.kind].get("boss")]

    # ---------- the design numbers ----------
    def test_data_file_holds_the_design_numbers(self):
        hero = self.data["hero"]
        self.assertEqual((hero["speed"], hero["max_hp"], hero["radius"]), (120, 100, 12))
        self.assertEqual(self.data["waves"][0]["types"], ["bat"])
        bat = self.data["enemies"]["bat"]
        self.assertEqual((bat["hp"], bat["speed"], bat["damage"]), (8, 100, 5))
        self.assertEqual((self.data["screen"]["width"], self.data["screen"]["height"]), (390, 700))

    def test_weapon_levels_come_from_the_data_file(self):
        spark = self.data["weapons"]["spark_wand"]
        first = rules.weapon_stats(self.data, "spark_wand", 1)
        self.assertEqual((first["damage"], first["interval"], first["count"]), (10, 0.8, 1))
        self.assertEqual(len(spark["levels"]), 5)
        # +3 damage and 0.08 s faster each level, +1 spark at levels 3 and 5
        self.assertEqual(
            [rules.weapon_stats(self.data, "spark_wand", n)["damage"] for n in range(1, 6)],
            [10, 13, 16, 19, 22],
        )
        self.assertEqual(
            [rules.weapon_stats(self.data, "spark_wand", n)["count"] for n in range(1, 6)],
            [1, 1, 2, 2, 3],
        )
        blades = [rules.weapon_stats(self.data, "spin_blades", n)["blades"] for n in range(1, 6)]
        self.assertEqual(blades, [2, 3, 3, 4, 4])
        ring = rules.weapon_stats(self.data, "holy_ring", 5)
        self.assertEqual((ring["damage"], ring["radius"]), (13, 90))

    # ---------- spawning ----------
    def test_one_spawn_tick_adds_at_most_the_per_second_cap(self):
        spawn = self.data["spawn"]
        minimum = self.data["waves"][0]["min_alive"]
        game = self.wave_game()
        game.step()
        self.assertEqual(len(game.enemies), min(minimum, spawn["max_per_tick"]))

    def test_spawning_fills_up_to_the_wave_minimum(self):
        minimum = self.data["waves"][0]["min_alive"]
        game = self.wave_game()
        for _ in range(ticks(self.data, 3)):
            game.step()
        self.assertEqual(len(game.enemies), minimum)

    def test_enemies_appear_on_the_spawn_circle(self):
        spawn = self.data["spawn"]
        bat = self.data["enemies"]["bat"]
        game = self.wave_game()
        game.step()
        self.assertTrue(game.enemies)
        for enemy in game.enemies:
            dist = math.hypot(enemy.x - game.hero_x, enemy.y - game.hero_y)
            self.assertLessEqual(dist, spawn["radius"])
            self.assertGreaterEqual(dist, spawn["radius"] - 2 * bat["speed"] * self.dt)

    def test_alive_count_is_capped(self):
        spawn = self.data["spawn"]
        game = rules.Game(
            self.patched(
                hero=dict(self.data["hero"], max_hp=10 ** 6),
                start_weapons=[],
                waves=[{"from": 0.0, "types": ["bat"], "min_alive": spawn["max_alive"] + 50}],
            ),
            seed=7,
        )
        for _ in range(ticks(self.data, 60)):
            game.step()
        self.assertEqual(game.status, "playing")
        self.assertEqual(len(game.enemies), spawn["max_alive"])

    def test_far_enemies_are_removed_but_a_boss_stays(self):
        game = self.solo_game()
        spawn = self.data["spawn"]
        game.data["enemies"] = dict(self.data["enemies"])
        game.data["enemies"]["boss_bat"] = dict(self.data["enemies"]["bat"], boss=True)
        game.add_enemy("bat", spawn["despawn_radius"] + 100, 0)
        game.add_enemy("boss_bat", -spawn["despawn_radius"] - 100, 0)
        for _ in range(ticks(self.data, 0.2)):
            game.step()
        self.assertEqual(sorted(e.kind for e in game.enemies), ["boss_bat"])

    # ---------- the wave table ----------
    def test_the_wave_table_matches_the_design(self):
        rows = {row["from"]: row for row in self.data["waves"]}
        self.assertEqual(sorted(rows), [0.0, 15.0, 30.0, 45.0, 60.0, 75.0, 90.0, 105.0])
        self.assertEqual([(rows[t]["types"], rows[t]["min_alive"]) for t in (0.0, 15.0)],
                         [(["bat"], 12), (["bat"], 20)])
        self.assertEqual(rows[30.0]["types"], ["bat", "slime"])
        self.assertEqual(rows[45.0]["types"], ["slime", "ghost"])
        self.assertEqual(rows[60.0]["types"], ["bat", "ghost"])
        self.assertEqual(rows[75.0]["types"], ["bat", "slime", "ghost"])
        self.assertEqual(rows[90.0]["types"], ["bat", "slime"])
        self.assertEqual(rows[105.0]["types"], ["bat"])
        self.assertEqual([rows[t]["min_alive"] for t in (30.0, 45.0, 60.0, 75.0, 90.0, 105.0)],
                         [28, 36, 45, 55, 55, 75])

    def test_the_enemy_numbers_match_the_design(self):
        enemies = self.data["enemies"]
        self.assertEqual(
            [enemies[k]["hp"] for k in ("bat", "slime", "ghost", "demon")], [8, 30, 15, 800]
        )
        self.assertEqual(
            [enemies[k]["speed"] for k in ("bat", "slime", "ghost", "demon")],
            [100, 55, 135, 85],
        )
        self.assertEqual(
            [enemies[k]["damage"] for k in ("bat", "slime", "ghost", "demon")], [5, 8, 6, 20]
        )
        self.assertEqual(
            [enemies[k]["xp"] for k in ("bat", "slime", "ghost", "demon")], [1, 2, 2, 0]
        )
        self.assertGreater(enemies["ghost"]["speed"], self.data["hero"]["speed"])
        self.assertTrue(enemies["demon"]["boss"])
        self.assertGreater(enemies["demon"]["picture_scale"], 1)

    def test_the_wave_that_applies_is_the_last_one_started(self):
        self.assertEqual(rules.wave_for(self.data, 0.0)["min_alive"], 12)
        self.assertEqual(rules.wave_for(self.data, 29.9)["min_alive"], 20)
        self.assertEqual(rules.wave_for(self.data, 30.0)["types"], ["bat", "slime"])
        self.assertEqual(rules.wave_for(self.data, 200.0)["min_alive"], 75)

    def test_a_later_wave_raises_the_minimum(self):
        game = self.tough_game()
        self.run_for(game, 20)
        self.assertEqual(len(game.enemies), self.data["waves"][1]["min_alive"])

    def test_only_the_types_of_the_current_wave_appear(self):
        game = self.tough_game(seed=4)
        self.run_for(game, 40)
        kinds = {e.kind for e in game.enemies}
        self.assertTrue(kinds <= {"bat", "slime"}, kinds)
        self.assertIn("slime", kinds)

    def test_slime_and_ghost_hurt_the_hero_with_their_own_numbers(self):
        for kind in ("slime", "ghost"):
            game = self.solo_game()
            enemy = self.data["enemies"][kind]
            hero = self.data["hero"]
            game.add_enemy(kind, hero["radius"] + enemy["radius"], 0)
            game.step()
            self.assertEqual(game.hp, hero["max_hp"] - enemy["damage"])

    def test_the_boss_appears_once_and_no_more(self):
        row = next(r for r in self.data["waves"] if "boss" in r)
        game = self.tough_game()
        self.run_for(game, row["from"] - 1)
        self.assertEqual(self.bosses(game), [])
        self.run_for(game, 2)
        self.assertEqual([e.kind for e in self.bosses(game)], [row["boss"]])
        self.run_for(game, 25)
        self.assertEqual(len(self.bosses(game)), 1, "the boss spawned twice")

    def test_the_boss_is_pulled_back_instead_of_despawning(self):
        spawn = self.data["spawn"]
        game = self.solo_game()
        boss = game.add_enemy("demon", spawn["boss_return_radius"] + 200, 0)
        self.run_for(game, 1)
        dist = math.hypot(boss.x - game.hero_x, boss.y - game.hero_y)
        self.assertLessEqual(dist, spawn["radius"] + self.data["enemies"]["demon"]["speed"] * self.dt)

    def test_the_boss_drops_no_gem(self):
        game = self.solo_game(weapons=True)
        game.data["enemies"] = dict(self.data["enemies"])
        game.data["enemies"]["demon"] = dict(
            self.data["enemies"]["demon"],
            hp=rules.weapon_stats(self.data, "spark_wand", 1)["damage"],
        )
        game.add_enemy("demon", 200, 0)
        self.run_for(game, 2)
        self.assertEqual(game.kills, 1)
        self.assertEqual(game.gems, [])

    # ---------- winning ----------
    def test_the_run_is_won_at_the_goal_time(self):
        goal = self.data["victory_seconds"]
        game = self.tough_game()
        self.run_for(game, goal - 1)
        self.assertEqual(game.status, "playing")
        self.run_for(game, 1.5)
        self.assertEqual(game.status, "victory")
        self.assertAlmostEqual(game.time, goal, places=6)

    def test_the_clock_stops_after_winning(self):
        game = self.solo_game()
        game.time = self.data["victory_seconds"] - self.dt / 2
        game.step()
        self.assertEqual(game.status, "victory")
        frozen = game.time
        self.run_for(game, 2)
        self.assertEqual(game.time, frozen)

    def test_playing_again_after_a_win_starts_from_zero(self):
        game = self.solo_game()
        game.time = self.data["victory_seconds"]
        game.step()
        self.assertEqual(game.status, "victory")
        game.reset()
        self.assertEqual((game.status, game.time, game.boss_rows), ("playing", 0.0, set()))

    # ---------- enemies chase the hero ----------
    def test_enemies_walk_toward_the_hero(self):
        game = self.solo_game()
        bat = self.data["enemies"]["bat"]
        enemy = game.add_enemy("bat", 200, 0)
        for _ in range(ticks(self.data, 1)):
            game.step()
        self.assertAlmostEqual(enemy.x, 200 - bat["speed"], places=3)
        self.assertAlmostEqual(enemy.y, 0.0, places=6)

    # ---------- hero ----------
    def test_hero_walks_to_the_aim_and_stops_at_the_dead_zone(self):
        game = self.solo_game()
        hero = self.data["hero"]
        target = hero["speed"] * 2
        game.set_aim(target, 0)
        game.step()
        self.assertAlmostEqual(game.hero_x, hero["speed"] * self.dt, places=6)
        for _ in range(ticks(self.data, 5)):
            game.step()
        stop_at = target - hero["stop_distance"]
        self.assertLessEqual(game.hero_x, stop_at + 1e-9)
        self.assertGreater(game.hero_x, stop_at - hero["speed"] * self.dt)

    def test_hero_does_not_walk_when_the_aim_is_in_the_dead_zone(self):
        game = self.solo_game()
        game.set_aim(5, 5)
        for _ in range(ticks(self.data, 1)):
            game.step()
        self.assertEqual((game.hero_x, game.hero_y), (0.0, 0.0))

    def test_contact_damage_respects_the_touch_cooldown(self):
        game = self.solo_game()
        bat = self.data["enemies"]["bat"]
        hero = self.data["hero"]
        game.add_enemy("bat", hero["radius"] + bat["radius"], 0)
        game.step()
        after_first_hit = hero["max_hp"] - bat["damage"]
        self.assertEqual(game.hp, after_first_hit)
        for _ in range(ticks(self.data, bat["touch_cooldown"] - 3 * self.dt)):
            game.step()
        self.assertEqual(game.hp, after_first_hit)
        for _ in range(ticks(self.data, 4 * self.dt)):
            game.step()
        self.assertEqual(game.hp, after_first_hit - bat["damage"])

    # ---------- spark wand ----------
    def test_spark_wand_kills_a_bat_and_drops_its_gem(self):
        game = self.solo_game(weapons=True)
        weapon = rules.weapon_stats(self.data, "spark_wand", 1)
        bat = self.data["enemies"]["bat"]
        self.assertLessEqual(bat["hp"], weapon["damage"])
        enemy = game.add_enemy("bat", 200, 0)
        seconds = weapon["interval"] + 200 / (weapon["speed"] + bat["speed"])
        for _ in range(ticks(self.data, seconds)):
            game.step()
        self.assertEqual(game.kills, 1)
        self.assertEqual(game.enemies, [])
        self.assertEqual([(g.x, g.y, g.xp) for g in game.gems], [(enemy.x, enemy.y, bat["xp"])])

    def test_spark_wand_shoots_once_per_interval(self):
        game = self.solo_game(weapons=True)
        weapon = rules.weapon_stats(self.data, "spark_wand", 1)
        self.unkillable(game, 0, -500)
        game.step()
        self.assertEqual(len(game.projectiles), 1)
        for _ in range(ticks(self.data, weapon["interval"])):
            game.step()
        self.assertEqual(len(game.projectiles), 2)
        self.assertEqual(game.kills, 0)

    def test_no_enemy_means_no_shots(self):
        game = self.solo_game(weapons=True)
        for _ in range(ticks(self.data, 2)):
            game.step()
        self.assertEqual(game.projectiles, [])

    # ---------- spin blades ----------
    def test_spin_blades_hit_an_enemy_again_only_after_their_cooldown(self):
        game = self.solo_game()
        game.data["weapons"] = dict(self.data["weapons"])
        blades = dict(game.data["weapons"]["spin_blades"], turn_seconds=0.2)
        blades["levels"] = [{"damage": 3, "blades": 1}]
        game.data["weapons"]["spin_blades"] = blades
        self.give(game, "spin_blades")
        enemy = self.unkillable(game, blades["radius"], 0)
        seconds = 1.5
        passes = seconds / blades["turn_seconds"]
        for _ in range(ticks(self.data, seconds)):
            game.step()
        hits = (enemy.max_hp - enemy.hp) / blades["levels"][0]["damage"]
        self.assertGreaterEqual(hits, 2)
        self.assertLess(hits, passes, "the per-blade cooldown should block some passes")
        self.assertLessEqual(hits, seconds / blades["hit_cooldown"] + 1)

    def test_spin_blades_do_not_hurt_enemies_outside_the_orbit(self):
        game = self.solo_game()
        self.give(game, "spin_blades")
        stats = rules.weapon_stats(self.data, "spin_blades", 1)
        far = self.unkillable(game, stats["radius"] + 60, 0)
        for _ in range(ticks(self.data, 3)):
            game.step()
        self.assertEqual(far.hp, far.max_hp)

    # ---------- holy ring ----------
    def test_holy_ring_hurts_everything_inside_its_radius_once_per_interval(self):
        game = self.solo_game()
        self.give(game, "holy_ring")
        stats = rules.weapon_stats(self.data, "holy_ring", 1)
        inside = [self.unkillable(game, stats["radius"] - 10, 0) for _ in range(2)]
        outside = self.unkillable(game, stats["radius"] + 40, 0)
        for _ in range(ticks(self.data, stats["interval"])):
            game.step()
        for gem in inside:
            self.assertEqual(gem.hp, gem.max_hp - stats["damage"])
        self.assertEqual(outside.hp, outside.max_hp)
        for _ in range(ticks(self.data, stats["interval"])):
            game.step()
        for gem in inside:
            self.assertEqual(gem.hp, gem.max_hp - 2 * stats["damage"])

    # ---------- gems, XP and level-up ----------
    def test_gems_only_fly_in_from_the_magnet_radius(self):
        game = self.solo_game()
        hero = self.data["hero"]
        magnet = game.magnet_radius()
        near = rules.Gem(magnet - 5, 0, 1)
        far = rules.Gem(magnet + hero["radius"] + 40, 0, 1)
        game.gems = [near, far]
        for _ in range(ticks(self.data, 2)):
            game.step()
        self.assertEqual(game.gems, [far])
        self.assertEqual(game.xp, 1)

    def test_xp_curve_and_the_level_up_pause(self):
        leveling = self.data["leveling"]
        game = self.solo_game()
        self.assertEqual(game.xp_needed(), leveling["first_level_xp"])
        game.add_xp(game.xp_needed() - 1)
        self.assertEqual((game.level, game.status), (1, "playing"))
        game.add_xp(1)
        self.assertEqual((game.level, game.status), (2, "choosing"))
        self.assertEqual(game.xp_needed(), leveling["first_level_xp"] + leveling["xp_step"])
        self.assertEqual(len(game.cards), leveling["cards"])

    def test_cards_are_different_and_never_above_the_highest_level(self):
        game = self.solo_game()
        game.passives["magnet"] = self.data["passives"]["magnet"]["levels"]
        game.add_xp(game.xp_needed())
        seen = [(card["kind"], card["name"]) for card in game.cards]
        self.assertEqual(len(seen), len(set(seen)), "the same card twice in one level-up")
        for card in game.cards:
            if card["kind"] == "weapon":
                self.assertLessEqual(card["level"], rules.max_weapon_level(self.data, card["name"]))
            elif card["kind"] == "passive":
                self.assertLessEqual(card["level"], self.data["passives"][card["name"]]["levels"])

    def test_a_card_cannot_offer_a_fourth_weapon(self):
        game = self.solo_game()
        for name in self.data["weapons"]:
            self.give(game, name)
        game.add_xp(game.xp_needed())
        self.assertGreaterEqual(len(game.weapons), self.data["leveling"]["max_weapons"])
        for card in game.cards:
            if card["kind"] == "weapon":
                self.assertIsNotNone(
                    game.weapon(card["name"]),
                    "a new weapon offered while the hero already has the maximum",
                )

    def test_choosing_resumes_the_game_and_applies_the_card(self):
        game = self.solo_game()
        game.add_xp(game.xp_needed())
        index = next(i for i, c in enumerate(game.cards) if c["kind"] == "passive")
        card = game.cards[index]
        game.choose(index)
        self.assertEqual(game.status, "playing")
        self.assertEqual(game.passives[card["name"]], card["level"])
        self.assertEqual(game.pending, 0)

    def test_two_level_ups_at_once_ask_for_two_cards(self):
        game = self.solo_game()
        step = self.data["leveling"]["xp_step"]
        first = game.xp_needed()
        game.add_xp(first + first + step)
        self.assertEqual((game.level, game.pending), (3, 2))
        game.choose(0)
        self.assertEqual((game.status, game.pending), ("choosing", 1))
        game.choose(0)
        self.assertEqual(game.status, "playing")

    def test_big_heart_card_raises_max_hp_and_heals(self):
        game = self.solo_game()
        per = self.data["passives"]["big_heart"]["per_level"]
        game.hp = 50
        game.cards = [{"kind": "passive", "name": "big_heart", "level": 1, "label": "Heart 1"}]
        game.status = "choosing"
        game.choose(0)
        self.assertEqual(game.max_hp, self.data["hero"]["max_hp"] + per["max_hp"])
        self.assertEqual(game.hp, 50 + per["heal"])

    def test_heal_card_when_nothing_is_left(self):
        game = self.solo_game()
        for name in self.data["weapons"]:
            self.give(game, name, rules.max_weapon_level(self.data, name))
        for name, conf in self.data["passives"].items():
            game.passives[name] = conf["levels"]
        game.hp = 10
        game.add_xp(game.xp_needed())
        self.assertEqual({card["kind"] for card in game.cards}, {"heal"})
        game.choose(0)
        self.assertEqual(game.hp, 10 + self.data["leveling"]["heal_card"]["amount"])

    def test_passives_change_walk_speed_and_magnet(self):
        game = self.solo_game()
        hero = self.data["hero"]
        boots = self.data["passives"]["swift_boots"]["per_level"]["speed_percent"]
        magnet = self.data["passives"]["magnet"]["per_level"]["magnet_radius"]
        game.passives = {"swift_boots": 2, "magnet": 3}
        self.assertAlmostEqual(game.walk_speed(), hero["speed"] * (1 + 2 * boots / 100))
        self.assertEqual(game.magnet_radius(), hero["magnet_radius"] + 3 * magnet)

    # ---------- events for the sound and feel code ----------
    def test_the_data_file_describes_the_sounds_and_the_feel(self):
        self.assertEqual(
            sorted(self.data["sounds"]), ["end", "gem", "hit", "hurt", "level_up"]
        )
        for name, conf in self.data["sounds"].items():
            self.assertIsInstance(conf["file"], str, name)
            self.assertGreaterEqual(conf["volume"], 0.0, name)
            self.assertLessEqual(conf["volume"], 1.0, name)
        feel = self.data["feel"]
        self.assertLess(feel["shake"]["pixels"], self.data["screen"]["width"] // 2)
        self.assertGreater(feel["shake"]["seconds"], 0.0)
        self.assertGreater(feel["damage_number"]["seconds"], 0.0)
        self.assertGreater(feel["flash"]["seconds"], 0.0)

    def test_take_events_empties_the_list(self):
        game = self.solo_game()
        bat = self.data["enemies"]["bat"]
        game.add_enemy("bat", self.data["hero"]["radius"] + bat["radius"], 0)
        game.step()
        self.assertTrue(game.take_events())
        self.assertEqual(game.take_events(), [])

    def test_a_spark_hit_reports_its_damage_where_it_landed(self):
        game = self.solo_game(weapons=True)
        weapon = rules.weapon_stats(self.data, "spark_wand", 1)
        enemy = self.unkillable(game, 0, -150)
        for _ in range(ticks(self.data, weapon["interval"] * 0.9)):
            game.step()
        hits = [event for event in game.take_events() if event[0] == "hit"]
        self.assertEqual(len(hits), 1)
        self.assertEqual(hits[0][3], weapon["damage"])
        self.assertAlmostEqual(enemy.hp, enemy.max_hp - weapon["damage"], places=6)

    def test_a_death_reports_the_spot_and_a_gem_reports_itself(self):
        game = self.solo_game(weapons=True)
        bat = self.data["enemies"]["bat"]
        game.add_enemy("bat", 40, 0)
        for _ in range(ticks(self.data, 2)):
            game.step()
        kinds = [event[0] for event in game.take_events()]
        self.assertIn("die", kinds)
        self.assertIn("gem", kinds)

    def test_getting_hurt_reports_the_amount(self):
        game = self.solo_game()
        bat = self.data["enemies"]["bat"]
        hero = self.data["hero"]
        game.add_enemy("bat", hero["radius"] + bat["radius"], 0)
        game.step()
        self.assertEqual(
            game.take_events(), [("hurt", game.hero_x, game.hero_y, bat["damage"])]
        )

    def test_a_level_up_is_reported(self):
        game = self.solo_game()
        game.take_events()
        game.add_xp(game.xp_needed())
        self.assertEqual(game.status, "choosing")
        self.assertEqual([event[0] for event in game.take_events()], ["level_up"])

    def test_losing_is_reported_as_the_end(self):
        game = self.solo_game()
        bat = self.data["enemies"]["bat"]
        game.hp = bat["damage"]
        game.add_enemy("bat", self.data["hero"]["radius"] + bat["radius"], 0)
        game.step()
        self.assertEqual(game.status, "game_over")
        self.assertIn(("end", False), game.take_events())

    def test_winning_is_reported_as_the_end(self):
        game = self.solo_game()
        game.time = self.data["victory_seconds"] - self.dt / 2
        game.step()
        self.assertEqual(game.status, "victory")
        self.assertEqual(game.take_events(), [("end", True)])

    def test_one_blade_pass_hurts_every_enemy_it_touches(self):
        game = self.solo_game()
        stats = rules.weapon_stats(self.data, "spin_blades", 1)
        self.give(game, "spin_blades")
        for _ in range(3):
            self.unkillable(game, stats["radius"], 0)
        game.step()
        dead = [event for event in game.take_events() if event[0] == "hit"]
        self.assertEqual(len(dead), 3, "enemies were skipped while the blade killed one")

    # ---------- lose, pause, play again ----------
    def test_hero_dies_at_zero_hp_and_the_run_freezes(self):
        game = self.solo_game()
        bat = self.data["enemies"]["bat"]
        game.hp = bat["damage"]
        game.add_enemy("bat", game.data["hero"]["radius"], 0)
        game.step()
        self.assertEqual(game.hp, 0)
        self.assertEqual(game.status, "game_over")
        frozen_time = game.time
        for _ in range(ticks(self.data, 2)):
            game.step()
        self.assertEqual(game.time, frozen_time)

    def test_dying_while_a_card_is_waiting_still_ends_the_run(self):
        game = self.solo_game()
        bat = self.data["enemies"]["bat"]
        game.hp = bat["damage"]
        game.xp = game.xp_needed() - bat["xp"]
        game.add_enemy("bat", game.data["hero"]["radius"], 0)
        game.gems = [rules.Gem(0, 0, bat["xp"])]
        game.step()
        self.assertEqual(game.hp, 0, "the bat and the gem should land in the same tick")
        self.assertEqual(game.status, "choosing")
        game.choose(0)
        self.assertEqual(game.status, "game_over")

    def test_pause_stops_the_clock(self):
        game = self.solo_game()
        game.step()
        game.toggle_pause()
        before = game.time
        for _ in range(ticks(self.data, 1)):
            game.step()
        self.assertEqual(game.time, before)
        game.toggle_pause()
        game.step()
        self.assertGreater(game.time, before)

    def test_reset_starts_a_fresh_run(self):
        game = self.solo_game()
        game.hp = self.data["enemies"]["bat"]["damage"]
        game.add_enemy("bat", game.data["hero"]["radius"], 0)
        game.step()
        self.assertEqual(game.status, "game_over")
        game.reset()
        self.assertEqual(game.status, "playing")
        self.assertEqual(game.hp, self.data["hero"]["max_hp"])
        self.assertEqual((game.time, game.kills, game.hero_x, game.level), (0.0, 0, 0.0, 1))
        self.assertEqual((game.enemies, game.projectiles, game.gems), ([], [], []))


if __name__ == "__main__":
    unittest.main()
