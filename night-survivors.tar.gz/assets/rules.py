"""Game rules for Night Survivors, with a fixed time step (1/60 s).

No pygame in this file: it only knows numbers and positions, so it can be tested
without a window and it runs the same way in a browser.
"""

import json
import math
import random
from pathlib import Path

DATA_PATH = Path(__file__).resolve().parent / "data" / "game.json"


def load_data(path=DATA_PATH):
    """Read all the game numbers from data/game.json."""
    return json.loads(Path(path).read_text())


def wave_for(data, t):
    """The wave row that applies at time t seconds (the last row started so far)."""
    chosen = None
    for row in data["waves"]:
        if row["from"] <= t:
            chosen = row
    return chosen


def weapon_stats(data, name, level):
    """The numbers for one weapon at one level: shared fields + that level's fields."""
    conf = data["weapons"][name]
    stats = {key: value for key, value in conf.items() if key != "levels"}
    stats.update(conf["levels"][level - 1])
    return stats


def max_weapon_level(data, name):
    return len(data["weapons"][name]["levels"])


class Enemy:
    __slots__ = ("id", "kind", "x", "y", "hp", "max_hp", "last_touch")

    def __init__(self, kind, x, y, hp, ident=0):
        self.id = ident
        self.kind = kind
        self.x = x
        self.y = y
        self.hp = hp
        self.max_hp = hp
        self.last_touch = -1e9


class Projectile:
    __slots__ = ("x", "y", "vx", "vy", "damage", "life", "radius", "color")

    def __init__(self, x, y, vx, vy, damage, life, radius, color):
        self.x = x
        self.y = y
        self.vx = vx
        self.vy = vy
        self.damage = damage
        self.life = life
        self.radius = radius
        self.color = color


class Gem:
    __slots__ = ("x", "y", "xp")

    def __init__(self, x, y, xp):
        self.x = x
        self.y = y
        self.xp = xp


class Game:
    """One run of the game. Call step() 60 times per second, never with your own dt."""

    def __init__(self, data, seed=None):
        self.data = data
        self.dt = data["time_step"]
        self.rng = random.Random(seed)
        self.reset()

    # ---------- input from main.py ----------
    def set_aim(self, x, y):
        """Walk toward this world position until we are within hero.stop_distance."""
        self.aim_x = x
        self.aim_y = y

    def stop_aim(self):
        self.aim_x = self.hero_x
        self.aim_y = self.hero_y

    def toggle_pause(self):
        if self.status == "playing":
            self.paused = not self.paused

    def choose(self, index):
        """Pick the card at index on the level-up screen."""
        if self.status != "choosing" or not 0 <= index < len(self.cards):
            return
        card = self.cards[index]
        if card["kind"] == "weapon":
            owned = self.weapon(card["name"])
            if owned:
                owned["level"] = card["level"]
            else:
                self.weapons.append(
                    {"name": card["name"], "level": card["level"], "cool": 0.0, "hits": {}}
                )
        elif card["kind"] == "passive":
            self.passives[card["name"]] = card["level"]
            per = self.data["passives"][card["name"]]["per_level"]
            if "max_hp" in per:
                self.max_hp += per["max_hp"]
            if "heal" in per:
                self.hp = min(self.max_hp, self.hp + per["heal"])
        else:
            amount = self.data["leveling"]["heal_card"]["amount"]
            self.hp = min(self.max_hp, self.hp + amount)
        self.pending -= 1
        if self.pending > 0:
            self._open_cards()
        else:
            self.cards = []
            self.status = "playing"
            self._check_dead()

    # ---------- one fixed tick ----------
    def step(self):
        if self.status != "playing" or self.paused:
            return
        self.time += self.dt
        if self.time >= self.data["victory_seconds"]:
            self.time = self.data["victory_seconds"]
            self.status = "victory"
            self.events.append(("end", True))
            return
        self._move_hero()
        self._spawn()
        self._move_enemies()
        self._contact_damage()
        self.orbit = self._orbit_points()
        self._fire_weapons()
        self._move_projectiles()
        self._move_gems()
        self._check_dead()

    def reset(self):
        hero = self.data["hero"]
        self.time = 0.0
        self.kills = 0
        self.status = "playing"
        self.paused = False
        self.hero_x = 0.0
        self.hero_y = 0.0
        self.hp = hero["max_hp"]
        self.max_hp = hero["max_hp"]
        self.aim_x = 0.0
        self.aim_y = 0.0
        self.level = 1
        self.xp = 0
        self.enemies = []
        self.projectiles = []
        self.gems = []
        self.orbit = []
        self.weapons = [
            {"name": name, "level": 1, "cool": 0.0, "hits": {}}
            for name in self.data["start_weapons"]
        ]
        self.passives = {}
        self.pending = 0
        self.cards = []
        self.spawn_timer = 0.0
        self.boss_rows = set()
        self.events = []
        self._ids = 1

    # ---------- hero numbers that come from the passives ----------
    def passive_bonus(self, key):
        total = 0
        for name, level in self.passives.items():
            per = self.data["passives"][name]["per_level"]
            total += per.get(key, 0) * level
        return total

    def walk_speed(self):
        hero = self.data["hero"]
        return hero["speed"] * (1 + self.passive_bonus("speed_percent") / 100.0)

    def magnet_radius(self):
        return self.data["hero"]["magnet_radius"] + self.passive_bonus("magnet_radius")

    def xp_needed(self):
        leveling = self.data["leveling"]
        return leveling["first_level_xp"] + leveling["xp_step"] * (self.level - 1)

    def weapon(self, name):
        for owned in self.weapons:
            if owned["name"] == name:
                return owned
        return None

    def add_xp(self, amount):
        self.xp += amount
        levels = 0
        while self.xp >= self.xp_needed():
            self.xp -= self.xp_needed()
            self.level += 1
            levels += 1
        if levels:
            self.pending += levels
            self._open_cards()

    # ---------- helpers ----------
    def take_events(self):
        """What happened since the last call, for the drawing and sound code."""
        events, self.events = self.events, []
        return events

    def _check_dead(self):
        if self.hp <= 0:
            self.hp = 0
            if self.status == "playing":
                self.status = "game_over"
                self.events.append(("end", False))

    def add_enemy(self, kind, x, y):
        """Make one enemy of this kind at this place (used when spawning and in tests)."""
        conf = self.data["enemies"][kind]
        enemy = Enemy(kind, x, y, conf["hp"], self._ids)
        self._ids += 1
        self.enemies.append(enemy)
        return enemy

    def _nearest_enemy(self, x, y):
        best = None
        best_d2 = None
        for e in self.enemies:
            d2 = (e.x - x) ** 2 + (e.y - y) ** 2
            if best_d2 is None or d2 < best_d2:
                best = e
                best_d2 = d2
        return best

    def _kill(self, enemy):
        self.enemies.remove(enemy)
        self.kills += 1
        self.events.append(("die", enemy.x, enemy.y))
        xp = self.data["enemies"][enemy.kind]["xp"]
        if xp > 0:
            self.gems.append(Gem(enemy.x, enemy.y, xp))

    def _damage(self, enemy, amount):
        enemy.hp -= amount
        self.events.append(("hit", enemy.x, enemy.y, amount))
        if enemy.hp <= 0:
            self._kill(enemy)

    # ---------- cards ----------
    def _card_pool(self):
        """Everything the hero could be offered right now."""
        leveling = self.data["leveling"]
        pool = []
        for name in self.data["weapons"]:
            owned = self.weapon(name)
            if owned is None:
                if len(self.weapons) < leveling["max_weapons"]:
                    pool.append(("weapon", name, 1))
            elif owned["level"] < max_weapon_level(self.data, name):
                pool.append(("weapon", name, owned["level"] + 1))
        for name, conf in self.data["passives"].items():
            level = self.passives.get(name, 0)
            if level < conf["levels"]:
                pool.append(("passive", name, level + 1))
        return pool

    def _make_card(self, kind, name, level):
        if kind == "heal":
            conf = self.data["leveling"]["heal_card"]
            return {"kind": "heal", "name": None, "level": 0, "label": conf["label"],
                    "text": conf["text"]}
        conf = self.data["weapons" if kind == "weapon" else "passives"][name]
        return {"kind": kind, "name": name, "level": level,
                "label": f"{conf['label']} {level}", "text": conf["card"]}

    def _open_cards(self):
        count = self.data["leveling"]["cards"]
        pool = self._card_pool()
        self.rng.shuffle(pool)
        self.cards = [self._make_card(*item) for item in pool[:count]]
        heal = self._make_card("heal", None, 0)
        while len(self.cards) < count:
            self.cards.append(dict(heal))
        self.status = "choosing"
        self.events.append(("level_up", self.level))

    # ---------- pieces of one tick ----------
    def _move_hero(self):
        hero = self.data["hero"]
        dx = self.aim_x - self.hero_x
        dy = self.aim_y - self.hero_y
        dist = math.hypot(dx, dy)
        if dist <= hero["stop_distance"] or dist == 0:
            return
        step = min(dist, self.walk_speed() * self.dt)
        self.hero_x += dx / dist * step
        self.hero_y += dy / dist * step

    def _spawn(self):
        spawn = self.data["spawn"]
        self.spawn_timer -= self.dt
        if self.spawn_timer > 0:
            return
        self.spawn_timer += spawn["interval"]
        row = wave_for(self.data, self.time)
        if row is None:
            return
        room = spawn["max_alive"] - len(self.enemies)
        boss = row.get("boss")
        if boss and row["from"] not in self.boss_rows and room > 0:
            self.boss_rows.add(row["from"])
            self.add_enemy(boss, *self._circle_point())
            room -= 1
        need = row["min_alive"] - len(self.enemies)
        for _ in range(max(0, min(need, room, spawn["max_per_tick"]))):
            self.add_enemy(self.rng.choice(row["types"]), *self._circle_point())

    def _circle_point(self):
        """A random point on the spawn circle around the hero, just off screen."""
        radius = self.data["spawn"]["radius"]
        angle = self.rng.uniform(0.0, math.tau)
        return self.hero_x + math.cos(angle) * radius, self.hero_y + math.sin(angle) * radius

    def _move_enemies(self):
        spawn = self.data["spawn"]
        kept = []
        for e in self.enemies:
            conf = self.data["enemies"][e.kind]
            dx = self.hero_x - e.x
            dy = self.hero_y - e.y
            dist = math.hypot(dx, dy)
            if conf.get("boss", False):
                # the boss is never removed: it walks back onto the spawn circle
                if dist > spawn["boss_return_radius"] and dist > 0:
                    e.x = self.hero_x - dx / dist * spawn["radius"]
                    e.y = self.hero_y - dy / dist * spawn["radius"]
            elif dist > spawn["despawn_radius"]:
                continue
            if dist > 0:
                step = min(dist, conf["speed"] * self.dt)
                e.x += dx / dist * step
                e.y += dy / dist * step
            kept.append(e)
        self.enemies = kept

    def _contact_damage(self):
        hero = self.data["hero"]
        for e in self.enemies:
            conf = self.data["enemies"][e.kind]
            reach = hero["radius"] + conf["radius"]
            if math.hypot(e.x - self.hero_x, e.y - self.hero_y) <= reach:
                if self.time - e.last_touch >= conf["touch_cooldown"]:
                    e.last_touch = self.time
                    self.hp -= conf["damage"]
                    self.events.append(("hurt", self.hero_x, self.hero_y, conf["damage"]))

    def _fire_weapons(self):
        for w in self.weapons:
            stats = weapon_stats(self.data, w["name"], w["level"])
            behavior = stats["behavior"]
            if behavior == "projectile":
                self._fire_projectiles(w, stats)
            elif behavior == "orbit":
                self._hit_orbit(w, stats)
            elif behavior == "pulse":
                self._pulse(w, stats)

    def _fire_projectiles(self, w, stats):
        w["cool"] -= self.dt
        if w["cool"] > 0:
            return
        target = self._nearest_enemy(self.hero_x, self.hero_y)
        if target is None:
            w["cool"] = 0.0
            return
        count = stats["count"]
        base = math.atan2(target.y - self.hero_y, target.x - self.hero_x)
        spread = math.radians(stats["spread_degrees"])
        for i in range(count):
            angle = base + (i - (count - 1) / 2) * spread
            self.projectiles.append(
                Projectile(
                    self.hero_x, self.hero_y,
                    math.cos(angle) * stats["speed"],
                    math.sin(angle) * stats["speed"],
                    stats["damage"], stats["lifetime"], stats["radius"],
                    list(stats["color"]),
                )
            )
        w["cool"] = stats["interval"]

    def _orbit_points(self):
        """Where every spinning blade is now, so the rules and the drawing agree."""
        points = []
        for w in self.weapons:
            stats = weapon_stats(self.data, w["name"], w["level"])
            if stats["behavior"] != "orbit":
                continue
            turn = stats["turn_seconds"]
            for i in range(stats["blades"]):
                angle = math.tau * self.time / turn + i * math.tau / stats["blades"]
                points.append(
                    {
                        "weapon": w["name"],
                        "blade": i,
                        "x": self.hero_x + math.cos(angle) * stats["radius"],
                        "y": self.hero_y + math.sin(angle) * stats["radius"],
                        "angle": angle,
                        "picture": stats["picture"],
                    }
                )
        return points

    def _hit_orbit(self, w, stats):
        for point in self.orbit:
            if point["weapon"] != w["name"]:
                continue
            for e in list(self.enemies):
                conf = self.data["enemies"][e.kind]
                reach = conf["radius"] + stats["hit_radius"]
                if math.hypot(e.x - point["x"], e.y - point["y"]) > reach:
                    continue
                key = (point["blade"], e.id)
                last = w["hits"].get(key, -1e9)
                if self.time - last < stats["hit_cooldown"]:
                    continue
                w["hits"][key] = self.time
                self._damage(e, stats["damage"])

    def _pulse(self, w, stats):
        w["cool"] -= self.dt
        if w["cool"] > 0:
            return
        w["cool"] = stats["interval"]
        w["pulsed_at"] = self.time
        for e in list(self.enemies):
            if math.hypot(e.x - self.hero_x, e.y - self.hero_y) <= stats["radius"]:
                self._damage(e, stats["damage"])

    def _move_projectiles(self):
        alive = []
        for p in self.projectiles:
            p.x += p.vx * self.dt
            p.y += p.vy * self.dt
            p.life -= self.dt
            hit = None
            if p.life > 0:
                for e in self.enemies:
                    conf = self.data["enemies"][e.kind]
                    if math.hypot(e.x - p.x, e.y - p.y) <= conf["radius"] + p.radius:
                        hit = e
                        break
            if hit is None:
                if p.life > 0:
                    alive.append(p)
                continue
            self._damage(hit, p.damage)
        self.projectiles = alive

    def _move_gems(self):
        magnet = self.magnet_radius()
        gem_speed = self.data["leveling"]["gem_speed"]
        hero = self.data["hero"]
        kept = []
        picked = 0
        for g in self.gems:
            dx = self.hero_x - g.x
            dy = self.hero_y - g.y
            dist = math.hypot(dx, dy)
            if dist <= hero["radius"]:
                picked += g.xp
                self.events.append(("gem", g.x, g.y))
                continue
            if dist <= magnet and dist > 0:
                step = min(dist, gem_speed * self.dt)
                g.x += dx / dist * step
                g.y += dy / dist * step
            kept.append(g)
        self.gems = kept
        if picked:
            self.add_xp(picked)


def format_time(seconds):
    """0:45 for a timer."""
    whole = int(seconds)
    return f"{whole // 60}:{whole % 60:02d}"
