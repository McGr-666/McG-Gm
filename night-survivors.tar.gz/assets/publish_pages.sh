#!/usr/bin/env bash
# Put the finished web build on GitHub Pages, so it opens on a phone.
# Run this after build_web.sh:
#
#   bash publish_pages.sh
#
# It makes a brand new PUBLIC repository named McG-Gm that contains only the
# web page, and turns Pages on for it.
set -euo pipefail
cd "$(dirname "$0")"

REPO_NAME="McG-Gm"

# pygbag writes either dist/index.html or dist/web/index.html
if [ -f dist/web/index.html ]; then
  OUT="$PWD/dist/web"
elif [ -f dist/index.html ]; then
  OUT="$PWD/dist"
else
  echo "there is no web build yet - run:  bash build_web.sh"
  exit 1
fi

command -v gh >/dev/null 2>&1 || { echo "gh is not installed"; exit 1; }
gh auth status >/dev/null 2>&1 || { echo "gh is not logged in - run: gh auth login"; exit 1; }

LOGIN=$(gh api user -q .login)
# the user part of a Pages address is lower case; the repo part keeps its spelling
PAGES_HOST=$(printf '%s' "$LOGIN" | tr '[:upper:]' '[:lower:]')
ADDRESS="https://$PAGES_HOST.github.io/$REPO_NAME/"

# copy the build into a clean folder and make it one commit
TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT
cp -R "$OUT"/. "$TMP"/
touch "$TMP/.nojekyll"   # Pages must not run Jekyll over the build files

git -C "$TMP" init -q -b main
git -C "$TMP" add -A
git -C "$TMP" -c user.name="$LOGIN" -c user.email="$LOGIN@users.noreply.github.com" \
  commit -qm "Night Survivors web build"

if gh repo view "$LOGIN/$REPO_NAME" >/dev/null 2>&1; then
  echo "repo $LOGIN/$REPO_NAME already exists - pushing this build on top of it"
  git -C "$TMP" remote add origin "https://github.com/$LOGIN/$REPO_NAME.git"
  git -C "$TMP" push -q -u origin main || {
    echo "the push was refused: the existing repo has unrelated history."
    echo "delete it first (gh repo delete $LOGIN/$REPO_NAME --force) and run me again,"
    echo "or change REPO_NAME at the top of this script."
    exit 1
  }
else
  (cd "$TMP" && gh repo create "$REPO_NAME" --public --source=. --remote=origin --push)
fi

# serve Pages from the root of the main branch
gh api -X POST "repos/$LOGIN/$REPO_NAME/pages" \
  -f 'source[branch]=main' -f 'source[path]=/' >/dev/null 2>&1 \
  || echo "Pages was already switched on - that is fine"

echo "waiting for GitHub to publish it..."
STATUS=""
for _ in $(seq 1 36); do
  STATUS=$(gh api "repos/$LOGIN/$REPO_NAME/pages" -q .status 2>/dev/null || echo "?")
  [ "$STATUS" = "built" ] && break
  sleep 5
done

echo "Pages status: $STATUS"
echo "open it on your phone:  $ADDRESS"
