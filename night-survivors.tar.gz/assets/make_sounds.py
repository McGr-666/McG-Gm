"""Make the game sounds from nothing but Python's standard library. Run me on your computer:

    python3 -m make_sounds

Every name in data/game.json -> "sounds" gets a short .wav file in sounds/.
main.py only loads the finished files (a browser cannot run this script).
"""

import array
import json
import math
import random
import wave
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "sounds"
RATE = 22050


def shape(kind, phase):
    """The value of one wave shape at this phase (0..1 is one full turn)."""
    turn = phase - math.floor(phase)
    if kind == "sine":
        return math.sin(math.tau * turn)
    if kind == "square":
        return 1.0 if turn < 0.5 else -1.0
    if kind == "saw":
        return 2.0 * turn - 1.0
    raise ValueError("unknown shape " + kind)


def note(freq, seconds, volume=0.8, kind="sine", decay=6.0, to=None):
    """One tone that fades out; `to` slides the pitch there over its length."""
    out = []
    phase = 0.0
    frames = max(1, int(seconds * RATE))
    for i in range(frames):
        at = i / frames
        phase += freq * ((to or freq) / freq) ** at / RATE
        fade = math.exp(-decay * at)
        if at > 0.9:  # a quick release, so the sample never ends on a click
            fade *= (1.0 - at) / 0.1
        out.append(shape(kind, phase) * volume * fade)
    return out


def rest(seconds):
    return [0.0] * int(seconds * RATE)


def join(*parts):
    return [value for part in parts for value in part]


def mix(*parts):
    length = max(len(part) for part in parts)
    return [(sum(part[i] if i < len(part) else 0.0 for part in parts)) for i in range(length)]


def noise(seconds, volume=0.5, decay=8.0, seed=7):
    rng = random.Random(seed)
    frames = int(seconds * RATE)
    out = []
    for i in range(frames):
        at = i / frames
        out.append((rng.random() * 2 - 1) * volume * math.exp(-decay * at))
    return out


# one builder per name in data/game.json -> "sounds"
BUILD = {
    "hit": lambda: note(880, 0.06, volume=0.7, kind="square", decay=9.0),
    "gem": lambda: join(note(1175, 0.05, decay=8.0), note(1568, 0.09, decay=7.0)),
    "level_up": lambda: join(
        note(659, 0.09, decay=5.0),
        note(831, 0.09, decay=5.0),
        note(988, 0.26, decay=4.0),
    ),
    "hurt": lambda: mix(
        note(196, 0.2, volume=0.7, kind="saw", decay=6.0, to=82),
        noise(0.09, volume=0.35, decay=14.0),
    ),
    "end": lambda: join(
        note(523, 0.16, decay=4.0),
        note(415, 0.16, decay=4.0),
        note(311, 0.5, decay=3.0),
    ),
}


def save(name, samples):
    """Write one mono 16 bit wav file, and say how loud it came out."""
    peak = max((abs(value) for value in samples), default=0.0)
    clipped = [max(-1.0, min(1.0, value)) for value in samples]
    frames = array.array("h", (round(value * 32767) for value in clipped))
    path = OUT / f"{name}.wav"
    with wave.open(str(path), "w") as handle:
        handle.setnchannels(1)
        handle.setsampwidth(2)
        handle.setframerate(RATE)
        handle.writeframes(frames.tobytes())
    print(
        "sounds/{}.wav  {:.2f}s  peak {:.2f}".format(
            name, len(samples) / RATE, peak
        )
    )


def main():
    data = json.loads((ROOT / "data" / "game.json").read_text())
    OUT.mkdir(exist_ok=True)
    for name in data["sounds"]:
        if name not in BUILD:
            raise SystemExit(f"data/game.json wants a sound named {name!r}, I have no recipe for it")
        save(name, BUILD[name]())
    extra = sorted(set(BUILD) - set(data["sounds"]))
    if extra:
        print("unused recipes (no such name in data/game.json):", ", ".join(extra))


if __name__ == "__main__":
    main()
