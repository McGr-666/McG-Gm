#!/usr/bin/env bash
# Put the finished web build on GitHub Pages, so it opens on a phone.
# Run this after build_web.sh:
#
#   bash publish_pages.sh
#
# The first run makes a brand new PUBLIC repository named McG-Gm that holds
# only the web page and turns Pages on. Later runs push the new build onto it
# as one more commit, so the address never changes.
set -euo pipefail
cd "$(dirname "$0")"

REPO_NAME="McG-Gm"

# pygbag writes its page into build/web
if [ -f build/web/index.html ]; then
  OUT="$PWD/build/web"
else
  echo "there is no web build yet - run:  bash build_web.sh"
  exit 1
fi

command -v gh >/dev/null 2>&1 || { echo "gh is not installed"; exit 1; }
gh auth status >/dev/null 2>&1 || { echo "gh is not logged in - run: gh auth login"; exit 1; }

LOGIN=$(gh api user -q .login)
# the user part of a Pages address is lower case; the repo part keeps its spelling
PAGES_HOST=$(printf '%s' "$LOGIN" | tr '[:upper:]' '[:lower:]')
ADDRESS="https://$PAGES_HOST.github.io/$REPO_NAME/"

WORK=$(mktemp -d)
trap 'rm -rf "$WORK"' EXIT
REPO="$WORK/repo"

# copy the build into a clean folder: only what the page needs to load
mkdir "$REPO"
cp -R "$OUT"/. "$REPO"/
# the .apk is the Android package; the page only unpacks the .tar.gz
# (pygbag reads the .apk when the host is an itch.io page), so it stays out
rm -f "$REPO"/*.apk
touch "$REPO/.nojekyll"   # Pages must not run Jekyll over the build files

if gh repo view "$LOGIN/$REPO_NAME" >/dev/null 2>&1; then
  echo "repo $LOGIN/$REPO_NAME exists - pushing this build as a new commit"
  git clone -q "https://github.com/$LOGIN/$REPO_NAME.git" "$WORK/old"
  git -C "$REPO" init -q -b main
  git -C "$REPO" remote add origin "https://github.com/$LOGIN/$REPO_NAME.git"
  # start from the current tip so the history stays short and readable
  COMMIT=$(git -C "$WORK/old" rev-parse origin/main)
  git -C "$REPO" fetch -q origin main
  git -C "$REPO" update-ref refs/heads/main "$COMMIT"
  git -C "$REPO" symbolic-ref HEAD refs/heads/main
else
  git -C "$REPO" init -q -b main
fi

git -C "$REPO" add -A
if git -C "$REPO" diff --cached --quiet HEAD 2>/dev/null; then
  echo "this build is already published - nothing to push"
else
  git -C "$REPO" -c user.name="$LOGIN" -c user.email="$LOGIN@users.noreply.github.com" \
    commit -qm "Night Survivors web build"
  if gh repo view "$LOGIN/$REPO_NAME" >/dev/null 2>&1; then
    git -C "$REPO" push -q origin main
  else
    (cd "$REPO" && gh repo create "$REPO_NAME" --public --source=. --remote=origin --push)
    # serve Pages from the root of the main branch
    gh api -X POST "repos/$LOGIN/$REPO_NAME/pages" \
      -f 'source[branch]=main' -f 'source[path]=/' >/dev/null 2>&1 \
      || echo "Pages was already switched on - that is fine"
  fi
fi

echo "waiting for GitHub to publish it..."
STATUS=""
for _ in $(seq 1 36); do
  STATUS=$(gh api "repos/$LOGIN/$REPO_NAME/pages" -q .status 2>/dev/null || echo "?")
  [ "$STATUS" = "built" ] && break
  sleep 5
done

echo "Pages status: $STATUS"
echo "open it on your phone:  $ADDRESS"
