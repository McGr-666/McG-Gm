#!/usr/bin/env bash
# Make the browser version of Night Survivors with pygbag.
#
#   bash build_web.sh
#
# Nothing outside this folder is changed: pygbag goes into .venv-web/ here,
# and the finished web page lands in build/web/.
set -euo pipefail
cd "$(dirname "$0")"

# 1. pygbag's own toolchain does not follow brand new Python releases,
#    so look for one it supports (3.8 - 3.12) before trying anything.
PY=""
for candidate in python3.12 python3.11 python3.10 python3.9 python3.8 python3; do
  if command -v "$candidate" >/dev/null 2>&1 &&
     "$candidate" -c 'import sys; raise SystemExit(0 if sys.version_info[:2] <= (3, 12) else 1)'; then
    PY="$candidate"
    break
  fi
done

if [ -z "$PY" ]; then
  echo "I need a Python between 3.8 and 3.12 to run pygbag, and this machine only has $(python3 -V 2>&1)."
  echo "One easy way to get it, without touching your current Python:"
  echo "    conda create -n pygbag python=3.12 -y"
  echo "    conda activate pygbag"
  echo "then run:  bash build_web.sh"
  exit 1
fi
echo "1/3 building with $("$PY" -V)"

# 2. install pygbag into a private virtualenv in this folder
if [ ! -d .venv-web ]; then
  "$PY" -m venv .venv-web
  .venv-web/bin/python -m pip install --quiet --upgrade pip
  .venv-web/bin/python -m pip install --quiet pygbag
fi
echo "2/3 pygbag installed in .venv-web/"

# 3. build this folder (--build means "do not start the local test server").
#    sounds/ holds .wav files; make_sounds.py can only write those with the
#    standard library, so tell pygbag not to insist on .ogg.
.venv-web/bin/pygbag --build --disable-sound-format-error --title "Night Survivors" .

# pygbag 0.9 writes index.html plus the archive into build/web
if [ -f build/web/index.html ]; then
  OUT=build/web
else
  echo "the build made no index.html under build/web - read the messages above"
  exit 1
fi
echo "3/3 done. $OUT/ is $(du -sh "$OUT" | cut -f1) and holds:"
ls "$OUT"

echo
echo "try it locally:   python3 -m http.server 8000 -d $OUT   ->  http://localhost:8000"
echo "show classmates:  bash publish_pages.sh"
