#!/usr/bin/env bash
# Make the browser version of Night Survivors with pygbag.
#
#   bash build_web.sh
#
# Nothing outside this folder is changed: pygbag goes into .venv-web/ here,
# and the finished web page lands in build/web/.
set -euo pipefail
cd "$(dirname "$0")"

# 1. install pygbag into a private virtualenv in this folder, once
if [ ! -d .venv-web ]; then
  # pygbag only needs Python 3.8 or newer to run, but its own toolchain lags
  # behind brand new releases, so prefer an older interpreter if there is one.
  PY=""
  for candidate in python3.12 python3.11 python3.10 python3.9 python3.8 python3; do
    if command -v "$candidate" >/dev/null 2>&1 &&
       "$candidate" -c 'import sys; raise SystemExit(0 if sys.version_info[:2] <= (3, 12) else 1)'; then
      PY="$candidate"
      break
    fi
  done
  if [ -z "$PY" ]; then
    echo "no Python found. The easiest way to get one without touching your current setup:"
    echo "    conda create -n pygbag python=3.12 -y"
    echo "    conda activate pygbag"
    echo "then run:  bash build_web.sh"
    exit 1
  fi
  echo "1/4 making .venv-web/ with $("$PY" -V)"
  "$PY" -m venv .venv-web
  .venv-web/bin/python -m pip install --quiet --upgrade pip
  .venv-web/bin/python -m pip install --quiet pygbag
else
  echo "1/4 .venv-web/ already has pygbag ($(.venv-web/bin/python -V 2>&1))"
fi
echo "2/4 building (this takes a minute)"

# 3. build this folder (--build means "do not start the local test server").
#    sounds/ holds .wav files; make_sounds.py can only write those with the
#    standard library, so tell pygbag not to insist on .ogg.
.venv-web/bin/pygbag --build --disable-sound-format-error --title "Night Survivors" .

# pygbag 0.9 writes index.html plus the archive into build/web
if [ -f build/web/index.html ]; then
  OUT=build/web
else
  echo "the build made no index.html under build/web - read the messages above"
  exit 1
fi
echo "3/4 done. $OUT/ is $(du -sh "$OUT" | cut -f1) and holds:"
ls "$OUT"

# 4. the template from pygbag is meant for a desktop tab: on a phone a drag on
#    the canvas would scroll or zoom the page instead of moving the hero.
python3 - "$OUT/index.html" <<'PY'
import sys

path = sys.argv[1]
text = open(path).read()
fix = """    <style id="phone-fix">
        /* dragging the thumb stick must steer, not scroll or zoom the page */
        html, body { overflow: hidden; overscroll-behavior: none; }
        canvas {
            touch-action: none;
            -webkit-user-select: none; user-select: none;
            -webkit-touch-callout: none;
        }
    </style>
</head>"""
if 'id="phone-fix"' not in text:
    open(path, "w").write(text.replace("</head>", fix, 1))
    print("4/4 added the phone rules to index.html")
else:
    print("4/4 the phone rules are already in index.html")
PY

echo
echo "try it locally:   python3 -m http.server 8000 -d $OUT   ->  http://localhost:8000"
echo "show classmates:  bash publish_pages.sh"
