"""Night Survivors - window, drawing and input.

The rules live in rules.py. This file only turns the world into pixels and
reads the mouse, keyboard and touch.
"""

import asyncio
import math
import os
import random
from pathlib import Path

import pygame

import rules

ROOT = Path(__file__).resolve().parent

# Optional headless self-check: NS_SELFTEST=13 python3 main.py
SELFTEST_SECONDS = float(os.environ.get("NS_SELFTEST", "0") or 0)
SELFTEST_SEED = os.environ.get("NS_SEED")


class Feel:
    """Damage numbers, death flashes and the screen shake: only ever for the screen."""

    def __init__(self, data):
        self.conf = data["feel"]
        self.numbers = []  # world x, world y, text, age in seconds
        self.flashes = []  # world x, world y, age
        self.shake = 0.0

    def add(self, events):
        for event in events:
            kind = event[0]
            if kind == "hit":
                self.numbers.append([event[1], event[2], str(round(event[3])), 0.0])
            elif kind == "die":
                self.flashes.append([event[1], event[2], 0.0])
            elif kind == "hurt":
                self.shake = self.conf["shake"]["seconds"]

    def tick(self, dt):
        for row in self.numbers:
            row[3] += dt
        for row in self.flashes:
            row[2] += dt
        life = self.conf["damage_number"]["seconds"]
        flash = self.conf["flash"]["seconds"]
        self.numbers = [row for row in self.numbers if row[3] < life]
        self.flashes = [row for row in self.flashes if row[2] < flash]
        self.shake = max(0.0, self.shake - dt)

    def reset(self):
        self.numbers = []
        self.flashes = []
        self.shake = 0.0

    def shift(self):
        """How many pixels to move the camera this frame, or (0, 0)."""
        if not self.shake:
            return (0, 0)
        pixels = self.conf["shake"]["pixels"]
        return (
            round(random.uniform(-pixels, pixels)),
            round(random.uniform(-pixels, pixels)),
        )


class Noises:
    """Plays the finished sound files, and never the same one twice in a row too fast."""

    def __init__(self, data, sounds):
        self.gaps = data["feel"]["sound_gap"]
        self.sounds = sounds
        self.next_at = {}
        self.played = {}

    def play(self, name, now):
        sound = self.sounds.get(name)
        if sound is None or now < self.next_at.get(name, 0.0):
            return
        self.next_at[name] = now + self.gaps.get(name, 0.0)
        sound.play()
        self.played[name] = self.played.get(name, 0) + 1


class Stick:
    """The thumb control in the bottom band: press, drag to walk, let go to stop.

    Screen positions only - the rules never see a stick, they only get an aim
    point in front of the hero, which is what a mouse already gave them.
    """

    def __init__(self, data, size):
        self.conf = data["joystick"]
        self.size = size
        self.base = None    # where this press started, in screen pixels
        self.knob = None    # where the handle is now, in screen pixels

    def in_zone(self, px, py):
        return py >= self.size[1] * (1.0 - self.conf["zone"])

    def press(self, px, py):
        """True when this touch belongs to the stick."""
        if not self.in_zone(px, py):
            return False
        self.base = (px, py)
        self.drag(px, py)
        return True

    def drag(self, px, py):
        """True when the stick was already held and moved here."""
        if self.base is None:
            return False
        dx, dy = px - self.base[0], py - self.base[1]
        dist = math.hypot(dx, dy)
        travel = self.conf["travel"]
        if dist > travel:
            self.knob = (self.base[0] + dx / dist * travel, self.base[1] + dy / dist * travel)
        else:
            self.knob = (px, py)
        return True

    def release(self):
        self.base = None
        self.knob = None

    @property
    def held(self):
        return self.base is not None

    def vector(self):
        """(direction x, direction y, strength), or None when nothing to do."""
        if not self.held:
            return None
        dx, dy = self.knob[0] - self.base[0], self.knob[1] - self.base[1]
        dist = math.hypot(dx, dy)
        if not dist:
            return None
        return (dx / dist, dy / dist, min(1.0, dist / self.conf["travel"]))

    def aim(self, game):
        """Where to walk: a point this far ahead of the hero, or None to stand."""
        pushed = self.vector()
        if not self.held:
            return None
        if pushed is None:
            return (game.hero_x, game.hero_y)
        dx, dy, strength = pushed
        reach = self.conf["reach"] * strength
        return (game.hero_x + dx * reach, game.hero_y + dy * reach)


def card_rects(size, count):
    """The three big cards, in the middle of the screen, top to bottom."""
    w, h = size
    margin, gap, height = 24, 14, 150
    top = (h - (count * height + (count - 1) * gap)) // 2
    return [
        pygame.Rect(margin, top + i * (height + gap), w - 2 * margin, height)
        for i in range(count)
    ]


def _selftest_script(size, data):
    """Fake input for the headless check: (time, event) or (time, action)."""
    cards = card_rects(size, 3)
    boss_from = next((row["from"] for row in data["waves"] if "boss" in row), None)

    def click(where):
        return pygame.event.Event(pygame.MOUSEBUTTONDOWN, pos=where, button=1)

    move = pygame.event.Event(pygame.MOUSEMOTION, pos=(320, 180), rel=(1, 1))
    up = pygame.event.Event(pygame.MOUSEBUTTONUP, pos=(300, 150), button=1)
    down = pygame.event.Event(pygame.FINGERDOWN, finger_id=0, x=0.25, y=0.85, dx=0.0, dy=0.0)
    drag = pygame.event.Event(pygame.FINGERMOTION, finger_id=0, x=0.25, y=0.62, dx=0.0, dy=0.0)
    lift = pygame.event.Event(pygame.FINGERUP, finger_id=0, x=0.25, y=0.62, dx=0.0, dy=0.0)
    key = pygame.event.Event(pygame.KEYDOWN, key=pygame.K_p, mod=0)
    unkey = pygame.event.Event(pygame.KEYUP, key=pygame.K_p, mod=0)
    tap_a_card = pygame.event.Event(
        pygame.FINGERDOWN,
        finger_id=1,
        x=cards[1].centerx / size[0],
        y=cards[1].centery / size[1],
        dx=0.0,
        dy=0.0,
    )
    lift_a_card = pygame.event.Event(
        pygame.FINGERUP,
        finger_id=1,
        x=cards[1].centerx / size[0],
        y=cards[1].centery / size[1],
        dx=0.0,
        dy=0.0,
    )

    def hold_the_stick(game):
        """One finger goes to the stick and stays there for the next steps."""
        if game.status != "playing":
            game.reset()
        pygame.event.post(down)
        pygame.event.post(drag)

    def open_cards(game):
        """Level up while that finger is still holding the stick."""
        game.add_xp(20)

    def level_up_twice(game):
        game.add_xp(20)

    def be_at_finished(game):
        """One bat on top of the hero, one hit left in his HP: the next tick must end it."""
        if game.status != "playing":
            game.reset()
        game.hp = game.data["enemies"]["bat"]["damage"]
        game.add_enemy("bat", game.hero_x, game.hero_y)

    def be_at_boss_wave(game):
        """Jump the clock to the row that has the boss, and stay alive to see it."""
        if game.status != "playing":
            game.reset()
        game.hp = game.max_hp = 10**6
        game.time = boss_from - 0.01

    def be_at_the_end(game):
        """One tick before 2:00: the next tick must win the run."""
        if game.status != "playing":
            game.reset()
        game.hp = game.max_hp = 10**6
        game.time = game.data["victory_seconds"] - 0.01

    plan = [
        (0.3, move),
        (1.1, click((300, 150))),
        (1.3, up),
        (2.0, down),
        (2.6, drag),
        (3.1, lift),
        (3.6, key),
        (4.2, key),
        (4.9, unkey),
        (5.2, level_up_twice),
        (5.6, click(cards[1].center)),
        (6.2, click(cards[0].center)),
        (6.8, click(cards[2].center)),
        (7.4, hold_the_stick),
        (7.7, open_cards),
        (8.2, tap_a_card),
        (8.4, lift_a_card),
        (8.6, lift),
        (8.9, be_at_finished),
        (9.7, click(cards[1].center)),
        (9.9, up),
        (10.3, be_at_boss_wave),
        (11.7, be_at_the_end),
        (12.3, click(cards[1].center)),
        (12.5, up),
    ]
    return plan


async def main():
    data = rules.load_data(ROOT / "data" / "game.json")
    size = (data["screen"]["width"], data["screen"]["height"])
    step = data["time_step"]

    pygame.init()
    screen = pygame.display.set_mode(size)
    pygame.display.set_caption(data["title"])
    fonts = {
        "small": pygame.font.Font(None, 22),
        "card": pygame.font.Font(None, 30),
        "big": pygame.font.Font(None, 52),
        "number": pygame.font.Font(None, data["feel"]["damage_number"]["font"]),
    }
    clock = pygame.time.Clock()
    pictures = load_pictures(data)
    sounds = load_sounds(data)
    feel = Feel(data)
    noises = Noises(data, sounds)
    stick = Stick(data, size)

    game = rules.Game(data, seed=int(SELFTEST_SEED) if SELFTEST_SEED else None)
    accumulator = 0.0
    elapsed = 0.0
    frames = 0
    script = _selftest_script(size, data) if SELFTEST_SECONDS else []
    seen = {}
    next_log = 0.5
    running = True

    def world(px, py):
        return px + game.hero_x - size[0] / 2, py + game.hero_y - size[1] / 2

    def pick_card(px, py):
        for index, rect in enumerate(card_rects(size, len(game.cards))):
            if rect.collidepoint(px, py):
                game.choose(index)
                return

    def restart():
        feel.reset()
        stick.release()
        game.reset()

    def react(events, now):
        """One sound per kind of thing that just happened."""
        feel.add(events)
        for event in events:
            kind = event[0]
            if kind == "hit":
                noises.play("hit", now)
            elif kind == "gem":
                noises.play("gem", now)
            elif kind == "level_up":
                noises.play("level_up", now)
            elif kind == "hurt":
                noises.play("hurt", now)
            elif kind == "end":
                noises.play("end", now)

    while running:
        dt = clock.tick(data["screen"]["fps"]) / 1000.0
        elapsed += dt
        frames += 1

        for event in pygame.event.get():
            if SELFTEST_SECONDS:
                name = pygame.event.event_name(event.type)
                seen[name] = seen.get(name, 0) + 1
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_p:
                    game.toggle_pause()
                elif event.key == pygame.K_ESCAPE:
                    running = False
            elif event.type == pygame.MOUSEMOTION:
                if game.status == "playing":
                    if not stick.drag(*event.pos):
                        game.set_aim(*world(*event.pos))
            elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                if game.status == "choosing":
                    pick_card(*event.pos)
                elif game.status != "playing":
                    restart()
                elif not stick.press(*event.pos):
                    game.set_aim(*world(*event.pos))
            elif event.type == pygame.MOUSEBUTTONUP and event.button == 1:
                if stick.held:
                    stick.release()
                    game.stop_aim()
            elif event.type in (pygame.FINGERDOWN, pygame.FINGERMOTION):
                px, py = event.x * size[0], event.y * size[1]
                if game.status == "choosing":
                    if event.type == pygame.FINGERDOWN:
                        pick_card(px, py)
                elif game.status == "playing":
                    # only the first finger steers, so a second one can tap a card
                    # while the stick is still held down
                    if event.finger_id != 0:
                        pass
                    elif event.type == pygame.FINGERDOWN:
                        stick.press(px, py)
                    else:
                        stick.drag(px, py)
                elif event.type == pygame.FINGERDOWN:
                    restart()
            elif event.type == pygame.FINGERUP:
                if event.finger_id == 0:
                    stick.release()
                    game.stop_aim()

        if game.status == "playing":
            # the hero keeps walking as he moves, so the aim is redone every frame
            aimed = stick.aim(game)
            if aimed is not None:
                game.set_aim(*aimed)

        while script and script[0][0] <= elapsed:
            _, item = script.pop(0)
            if callable(item):
                item(game)
            else:
                pygame.event.post(item)

        accumulator = min(accumulator + dt, 5 * step)
        while accumulator >= step:
            game.step()
            accumulator -= step
        react(game.take_events(), elapsed)
        feel.tick(dt)

        draw(screen, fonts, data, game, pictures, feel, stick)
        pygame.display.flip()

        if SELFTEST_SECONDS and elapsed >= next_log:
            kinds = {}
            for e in game.enemies:
                kinds[e.kind] = kinds.get(e.kind, 0) + 1
            row = rules.wave_for(data, game.time)
            pushed = stick.vector()
            print(
                "[selftest] t={:4.1f} run={:5.1f} {:8s} lv={} xp={}/{} hp={:5.0f} "
                "enemies={:3d} kinds={} boss={} wave={} kills={:2d} numbers={} "
                "flashes={} shake={} pos={} stick={} cards={} paused={}".format(
                    elapsed, game.time, game.status, game.level, game.xp, game.xp_needed(),
                    game.hp, len(game.enemies), dict(sorted(kinds.items())),
                    sum(1 for e in game.enemies if data["enemies"][e.kind].get("boss")),
                    row["from"] if row else "-", game.kills,
                    len(feel.numbers), len(feel.flashes), round(feel.shake, 2),
                    (round(game.hero_x), round(game.hero_y)),
                    "-" if pushed is None else (round(pushed[0], 1), round(pushed[1], 1),
                                                round(pushed[2], 2)),
                    [card["label"] for card in game.cards], game.paused,
                )
            )
            next_log += 0.5

        if SELFTEST_SECONDS and elapsed >= SELFTEST_SECONDS:
            print(
                "[selftest] frames={} fps={:.1f} status={} run={:.1f} level={} weapons={} "
                "passives={} sounds={} events={}".format(
                    frames, clock.get_fps(), game.status, game.time, game.level,
                    [(w["name"], w["level"]) for w in game.weapons],
                    game.passives, dict(sorted(noises.played.items())), dict(sorted(seen.items())),
                )
            )
            running = False

        await asyncio.sleep(0)

    pygame.quit()


def draw(screen, fonts, data, game, pictures, feel, stick):
    hero = data["hero"]
    ui = data["ui"]
    small = fonts["small"]
    feel_conf = data["feel"]
    w, h = screen.get_size()
    shake_x, shake_y = feel.shift()
    left = game.hero_x - w / 2 + shake_x
    top = game.hero_y - h / 2 + shake_y

    tile = pictures[data["floor"]["picture"]]
    size = tile.get_width()
    y = -top % size - size
    while y < h:
        x = -left % size - size
        while x < w:
            screen.blit(tile, (x, y))
            x += size
        y += size

    for g in game.gems:
        blit_center(screen, gem_picture(data, pictures, g.xp), g.x - left, g.y - top)

    for e in game.enemies:
        blit_center(screen, enemy_picture(pictures, data["enemies"][e.kind]), e.x - left, e.y - top)

    # a ring where an enemy just died
    for x, y, age in feel.flashes:
        ratio = age / feel_conf["flash"]["seconds"]
        radius = round(feel_conf["flash"]["radius"] * (0.5 + ratio))
        ring(screen, ui["flash"], (x - left, y - top), radius, round(255 * (1.0 - ratio)), 3)

    for owned in game.weapons:
        stats = rules.weapon_stats(data, owned["name"], owned["level"])
        if stats["behavior"] == "pulse":
            recent = game.time - owned.get("pulsed_at", -9) < 0.12
            pygame.draw.circle(
                screen, stats["color"], (game.hero_x - left, game.hero_y - top),
                stats["radius"], 3 if recent else 1,
            )

    blit_center(screen, pictures[hero["picture"]], game.hero_x - left, game.hero_y - top)

    for point in game.orbit:
        image = pictures[point["picture"]]
        turned = pygame.transform.rotate(image, -math.degrees(point["angle"]))
        blit_center(screen, turned, point["x"] - left, point["y"] - top)

    for p in game.projectiles:
        pygame.draw.circle(screen, p.color, (p.x - left, p.y - top), p.radius)

    # damage numbers float up and fade out
    numbers = feel_conf["damage_number"]
    for x, y, label, age in feel.numbers:
        ratio = age / numbers["seconds"]
        alpha = 255 if ratio < 0.5 else round(255 * (1.0 - ratio) / 0.5)
        at = (x - left, y - top - numbers["rise"] * ratio)
        faded_text(screen, fonts["number"], label, at[0] + 1, at[1] + 1, ui["shadow"], alpha)
        faded_text(screen, fonts["number"], label, *at, ui["damage_number"], alpha)

    # the fade goes under the HUD so the bars and the timer stay readable
    if game.status == "choosing":
        draw_cards(screen, fonts, data, game)
    elif game.paused and game.status == "playing":
        fade(screen, ui["overlay"], 150)
        centered_at(screen, fonts["big"], "P PAUSED", ui["text"], h // 2)
        centered_at(screen, small, "press P to continue", ui["text"], h // 2 + 40)
    elif game.status != "playing":
        fade(screen, ui["overlay"], 200)
        won = game.status == "victory"
        title = "VICTORY" if won else "GAME OVER"
        color = ui["victory"] if won else ui["game_over"]
        centered_at(screen, fonts["big"], title, color, h // 2 - 60)
        centered_at(
            screen, small,
            f"time {rules.format_time(game.time)}   kills {game.kills}   Lv {game.level}",
            ui["text"], h // 2,
        )
        centered_at(screen, small, "click or tap to play again", ui["text"], h // 2 + 40)

    # top left: HP bar, XP bar, level; top right: the timer
    bar_w = 140
    pygame.draw.rect(screen, ui["hp_bar_back"], (10, 10, bar_w, 12))
    pygame.draw.rect(screen, ui["hp_bar"], (10, 10, bar_w * max(0.0, game.hp / game.max_hp), 12))
    pygame.draw.rect(screen, ui["xp_bar_back"], (10, 26, bar_w, 8))
    pygame.draw.rect(
        screen, ui["xp_bar"], (10, 26, bar_w * min(1.0, game.xp / game.xp_needed()), 8)
    )
    text(screen, small, f"{max(0, round(game.hp))}", 10 + bar_w + 8, 8, ui["text"], ui["shadow"])
    text(screen, small, f"{game.xp}/{game.xp_needed()}", 10 + bar_w + 8, 24, ui["text"], ui["shadow"])
    text(screen, small, f"Lv {game.level}", 10, 40, ui["text"], ui["shadow"])
    goal = rules.format_time(data["victory_seconds"])
    label = f"{rules.format_time(min(game.time, data['victory_seconds']))} / {goal}"
    text(screen, small, label, w - 12 - small.size(label)[0], 10, ui["text"], ui["shadow"])

    # bottom: what you have, wrapped so a full build still fits the narrow window
    items = [
        f"{data['weapons'][owned['name']]['label']} {owned['level']}" for owned in game.weapons
    ] + [
        f"{data['passives'][name]['label']} {level}" for name, level in game.passives.items()
    ]
    lines = [[]]
    for item in items:
        joined = "  ".join(lines[-1] + [item])
        if lines[-1] and small.size(joined)[0] > w - 24:
            lines.append([item])
        else:
            lines[-1].append(item)
    for row, line in enumerate(reversed(["  ".join(row) for row in lines if row])):
        text(screen, small, line, 12, h - 26 - 20 * row, ui["text"], ui["shadow"])

    # the thumb control last, so the world can never be drawn on top of it
    if game.status == "playing" and not game.paused:
        draw_stick(screen, data, ui, stick)


def draw_stick(screen, data, ui, stick):
    """The dim ring where the stick lives, and the handle while it is held."""
    conf = data["joystick"]
    w, h = screen.get_size()
    if stick.held:
        base, knob, alpha = stick.base, stick.knob, 210
    else:
        base = (conf["home"][0] * w, conf["home"][1] * h)
        knob = base
        alpha = conf["hint"]
    disc(screen, ui["stick_base"], base, conf["base"], alpha)
    ring(screen, ui["stick_edge"], base, conf["base"], alpha, 2)
    disc(screen, ui["stick_knob"], knob, conf["knob"], min(255, alpha + 55))


def draw_cards(screen, fonts, data, game):
    ui = data["ui"]
    fade(screen, ui["overlay"], 170)
    centered_at(screen, fonts["small"], f"Lv {game.level} - choose one", ui["card_title"], 60)
    rects = card_rects(screen.get_size(), len(game.cards))
    for rect, card in zip(rects, game.cards):
        pygame.draw.rect(screen, ui["card"], rect, border_radius=10)
        pygame.draw.rect(screen, ui["card_edge"], rect, 2, border_radius=10)
        centered_in(screen, fonts["card"], card["label"], rect, -30, ui["card_title"])
        centered_in(screen, fonts["small"], card["text"], rect, 10, ui["text"])


def centered_in(screen, font, string, rect, dy, color):
    image = font.render(string, True, color)
    screen.blit(image, (rect.centerx - image.get_width() // 2, rect.centery + dy))


def gem_picture(data, pictures, xp):
    row = min(data["gems"], key=lambda gem: abs(gem["xp"] - xp))
    return pictures[row["picture"]]


def fade(screen, color, alpha):
    w, h = screen.get_size()
    layer = pygame.Surface((w, h), pygame.SRCALPHA)
    layer.fill((*color, alpha))
    screen.blit(layer, (0, 0))


def blit_center(screen, image, x, y):
    screen.blit(image, (round(x - image.get_width() / 2), round(y - image.get_height() / 2)))


def load_pictures(data):
    """Load every finished picture the data file points at, from assets/."""
    wanted = {data["hero"]["picture"], data["floor"]["picture"]}
    wanted.update(conf["picture"] for conf in data["enemies"].values())
    wanted.update(gem["picture"] for gem in data["gems"])
    wanted.update(conf["picture"] for conf in data["weapons"].values() if "picture" in conf)
    pictures = {}
    for name in sorted(wanted):
        path = ROOT / "assets" / f"{name}.png"
        if not path.exists():
            raise SystemExit(f"missing picture {path} - run: python3 -m make_assets")
        pictures[name] = pygame.image.load(str(path)).convert_alpha()
    for conf in data["enemies"].values():
        scale = conf.get("picture_scale", 1)
        name = conf["picture"]
        if scale != 1 and big_picture(name, scale) not in pictures:
            pictures[big_picture(name, scale)] = pygame.transform.scale_by(pictures[name], scale)
    return pictures


def big_picture(name, scale):
    return name if scale == 1 else f"{name}x{scale}"


def load_sounds(data):
    """The finished files from sounds/ - .ogg if it is there, otherwise .wav."""
    if not pygame.mixer.get_init():
        print("no sound device: the game runs silently")
        return {}
    sounds = {}
    for name, conf in data["sounds"].items():
        for extension in (".ogg", ".wav"):
            path = ROOT / "sounds" / (conf["file"] + extension)
            if path.exists():
                break
        else:
            raise SystemExit(
                f"missing sound {ROOT / 'sounds' / conf['file']}.ogg/.wav"
                " - run: python3 -m make_sounds"
            )
        sound_path = path
        try:
            sound = pygame.mixer.Sound(str(sound_path))
        except pygame.error as problem:
            # a browser or a phone may refuse one of the formats; the game still plays
            print(f"cannot play {sound_path.name}: {problem}")
            continue
        sound.set_volume(conf["volume"])
        sounds[name] = sound
    return sounds


def enemy_picture(pictures, conf):
    return pictures[big_picture(conf["picture"], conf.get("picture_scale", 1))]


def text(screen, font, string, x, y, color, shadow):
    screen.blit(font.render(string, True, shadow), (x + 1, y + 1))
    screen.blit(font.render(string, True, color), (x, y))


def faded_text(screen, font, string, x, y, color, alpha):
    image = font.render(string, True, color)
    image.set_alpha(alpha)
    screen.blit(image, (round(x), round(y)))


def ring(screen, color, pos, radius, alpha, width):
    """A circle that can fade out, which pygame.draw.circle cannot do."""
    side = radius * 2 + 4
    layer = pygame.Surface((side, side), pygame.SRCALPHA)
    pygame.draw.circle(layer, (*color, alpha), (side // 2, side // 2), radius, width)
    screen.blit(layer, (pos[0] - side // 2, pos[1] - side // 2))


def disc(screen, color, pos, radius, alpha):
    """A filled circle that can be see-through, which pygame.draw.circle cannot be."""
    side = radius * 2 + 4
    layer = pygame.Surface((side, side), pygame.SRCALPHA)
    pygame.draw.circle(layer, (*color, alpha), (side // 2, side // 2), radius)
    screen.blit(layer, (pos[0] - side // 2, pos[1] - side // 2))


def centered_at(screen, font, string, color, y):
    img = font.render(string, True, color)
    screen.blit(img, (screen.get_width() // 2 - img.get_width() // 2, y))


if __name__ == "__main__":
    asyncio.run(main())
